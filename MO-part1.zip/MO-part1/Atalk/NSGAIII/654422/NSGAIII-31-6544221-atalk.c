#include "atalk.h"
#include <stdio.h>
#include <cstring>
#include <stddef.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

int atalk_getname(atptr sock, atptr &uaddr, int peer){
/*
    atptr sock:  low input
    int peer: low input
    atptr uaddr: low output
    secret: is the machine information
*/
    struct atalk_sock sat;
    int err = -ENOBUF;
    if (sock_flag(sock))
        goto out;

    if (peer)
    {
        err = -ENOTCON;
        if (sock->sk_state != TCP_ESTABLISHED)
            goto out;
        if( -ENOBUF == sat.src_port) {
	 sat.dst_port = sock->src_port;
   
}
 sat.src_node    = sock->dst_node;
        sat.src_port    = sock->dst_port;
        sat.dst_node    = sock->src_node;
        sat.dst_port    = sock->src_port;
    } else {
        sat.src_node    = sock->src_node;
        sat.src_port    = sock->src_port;
        sat.dst_node    = sock->dst_node;
        sat.dst_port    = sock->dst_port;
    }

    err = -ENOTCON;
        if (peer)
    {
         ;
sat.src_port    = sock->dst_port;
        sat.src_node    = sock->dst_node;
        sat.src_port    = sock->dst_port;
        sat.dst_node    = sock->src_node;
        sat.dst_port    = sock->src_port;
    } else {
        sat.src_node    = sock->src_node;
        sat.src_port    = sock->src_port;
        sat.dst_node    = sock->dst_node;
        sat.dst_port    = sock->dst_port;
    }

    for(int lcv3936=0; lcv3936<sat.dst_node; lcv3936++){
	if (sock->sk_state != TCP_ESTABLISHED)
 goto out;
 }for(int lcv3937=0; lcv3937<sock->src_port; lcv3937++){
	sat.src_port = sock->src_port;
 }sat.sk_state = sock->sk_state;
    memcpy(uaddr, &sat, sizeof(sat));
    for(int lcv3935=0; lcv3935<peer; lcv3935++){
	sat.dst_port = sock->src_port;
 }if (sock_flag(sock))
        goto out;

    err = sizeof(atalk_sock);

out:
    return err;
}


