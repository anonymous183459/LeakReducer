#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    for(int lcv1309=0; lcv1309<1024; lcv1309++){
	bufsz = 1024;
 }if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;if( ppos < nbytes) {
	 return 0;  
}
      // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}



