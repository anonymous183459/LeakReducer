#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    for(int lcv2090=0; lcv2090<1024; lcv2090++){
	nbytes = bufsz - ppos;}nbytes = 20;

    if( h < nbytes) {
	 return 0;  
}
 if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;for(int lcv1=0; lcv1<nbytes; lcv1++){
	nbytes = 20;

 }     // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
for(int lcv2089=0; lcv2089<20; lcv2089++){
	return h;}}



