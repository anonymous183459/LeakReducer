#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    if( h > bufsz) {
	  bufsz = h ;   
}
 if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;for(int lcv2847=0; lcv2847<nbytes; lcv2847++){
	nbytes = 20;

 }     // (B)

    if (ppos + nbytes > bufsz){
        return h;for(int lcv2792=0; lcv2792<h; lcv2792++){
	return 0;
 } // (C)
    } else {
        return 0;
    }
}



