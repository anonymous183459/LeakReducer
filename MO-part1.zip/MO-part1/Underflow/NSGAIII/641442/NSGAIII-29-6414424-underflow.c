#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;for(int lcv2941=0; lcv2941<20; lcv2941++){
	bufsz = 1024;
 }     // (B)

    if (ppos + nbytes > bufsz){
        return h;for(int lcv2303=0; lcv2303<20; lcv2303++){
	return h;} // (C)
    } else {
        return 0;
    }
}



