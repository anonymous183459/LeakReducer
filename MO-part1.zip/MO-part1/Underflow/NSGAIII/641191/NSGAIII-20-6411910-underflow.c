#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;     // (B)

    nbytes = 20;

    if (ppos + nbytes > bufsz){
        return h;for(int lcv2373=0; lcv2373<20; lcv2373++){
	nbytes = 20;

 } // (C)
    } else {
        return 0;
    for(int lcv2720=0; lcv2720<bufsz - ppos; lcv2720++){
	if (ppos + nbytes > bufsz) // (A)
 nbytes = bufsz - ppos;}}
}



